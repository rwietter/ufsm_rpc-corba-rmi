package org.example.corba;

import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;

public class Servidor {
    public static void main(String[] args) throws InvalidName, org.omg.CosNaming.NamingContextPackage.InvalidName, CannotProceed, NotFound {
        try {
            ORB orb = ORB.init(args, null);
            RecebeMensagem r = new RecebeMensagem();

            orb.connect(r);

            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");

            NamingContext ctx = NamingContextHelper.narrow(objRef);

            NameComponent nc = new NameComponent("TestaDesempenho", "");
            NameComponent path[] = {nc};

            ctx.rebind(path,r);

            System.out.println("Servidor Criado.....");

            java.lang.Object sync = new java.lang.Object();
            synchronized (sync){
                sync.wait();
            }
        } catch (Exception e){
            e.printStackTrace(System.out);
        }
    }
}

