package org.example.rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;

public class Servidor {
	public static void main(String[] args) {
		try {
			IServidorRMI ncRef = new RecebeMensagem();
			System.out.println("Iniciando servidor");
			Naming.rebind("IServidorRMI", ncRef);
		} catch (RemoteException | MalformedURLException e) {
			throw new RuntimeException(e);
		}
	}
}
