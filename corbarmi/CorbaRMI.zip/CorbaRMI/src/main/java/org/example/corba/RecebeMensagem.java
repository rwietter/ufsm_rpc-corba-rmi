package org.example.corba;

class RecebeMensagem extends  _IServidorCorbaStub {
    int i = 0;

    public void envia(boolean msg){
        i++;
        if(i==100) {
            System.out.println(i);
        }
    }
}