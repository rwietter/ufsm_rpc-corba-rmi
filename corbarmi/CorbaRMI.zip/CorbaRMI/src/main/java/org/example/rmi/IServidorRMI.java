package org.example.rmi;

public interface IServidorRMI extends java.rmi.Remote {
	void envia(boolean mensagem);
}
