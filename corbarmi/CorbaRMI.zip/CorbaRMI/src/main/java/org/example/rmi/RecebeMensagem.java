package org.example.rmi;

import java.rmi.RemoteException;

public class RecebeMensagem extends java.rmi.server.UnicastRemoteObject implements IServidorRMI {
	int i = 0;

	protected RecebeMensagem() throws RemoteException {
	}

	public void envia(boolean mensagem) {
		i++;
		if (i == 100) {
			System.out.println(i);
		}
	}
}
