package org.example.rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class Cliente {
	public static void main(String[] args) {
		long tempoInicial;
		long tempoFinal;
		int counter;
		boolean msg = true;

		try {
			IServidorRMI test = (IServidorRMI) Naming.lookup("//localhost/IServidorRMI");

			tempoInicial = System.currentTimeMillis();

			for (counter = 0; counter < 1000; counter++) {
				test.envia(msg);
			}

			tempoFinal = System.currentTimeMillis();

			System.out.println(tempoFinal - tempoInicial);
		} catch (NotBoundException e) {
			throw new RuntimeException(e);
		} catch (MalformedURLException e) {
			throw new RuntimeException(e);
		} catch (RemoteException e) {
			throw new RuntimeException(e);
		}

	}
}
